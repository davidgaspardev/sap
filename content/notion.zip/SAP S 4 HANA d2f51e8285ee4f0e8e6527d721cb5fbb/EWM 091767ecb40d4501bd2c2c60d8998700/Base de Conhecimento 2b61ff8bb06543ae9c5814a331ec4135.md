# Base de Conhecimento

Owner: Leonardo