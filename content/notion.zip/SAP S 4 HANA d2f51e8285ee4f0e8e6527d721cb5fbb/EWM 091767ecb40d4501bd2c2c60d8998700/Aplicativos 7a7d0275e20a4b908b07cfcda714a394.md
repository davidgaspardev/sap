# Aplicativos

Owner: Leonardo

- SAP EWM Mobile App
- SAP EWM RF Framework
- SAP EWM Cockpit App
- SAP EWM Warehouse Order Creation App
- SAP EWM Warehouse Monitor App
- SAP EWM Yard Logistics App

![Untitled](Aplicativos%207a7d0275e20a4b908b07cfcda714a394/Untitled.png)

[ZEWM0001 - Parâmetros de Etiqueta UC](Aplicativos%207a7d0275e20a4b908b07cfcda714a394/ZEWM0001%20-%20Para%CC%82metros%20de%20Etiqueta%20UC%2097b8c6739c144f9293ee98071aa13820.md)