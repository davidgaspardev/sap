# Condicionar Impressão de Etiqueta UC

Owner: Leonardo

Acessar a transação /scwm/prhu6

![Untitled](Condicionar%20Impressa%CC%83o%20de%20Etiqueta%20UC%20708cd2f9e0c64c6d9aac290edca04c74/Untitled.png)

Informar filtros Iniciais

![Untitled](Condicionar%20Impressa%CC%83o%20de%20Etiqueta%20UC%20708cd2f9e0c64c6d9aac290edca04c74/Untitled%201.png)

Selecionar registros por Centro de Depósito

![Untitled](Condicionar%20Impressa%CC%83o%20de%20Etiqueta%20UC%20708cd2f9e0c64c6d9aac290edca04c74/Untitled%202.png)

Filtrar Deposito

![Untitled](Condicionar%20Impressa%CC%83o%20de%20Etiqueta%20UC%20708cd2f9e0c64c6d9aac290edca04c74/Untitled%203.png)

Encontrar regra desejada

![Untitled](Condicionar%20Impressa%CC%83o%20de%20Etiqueta%20UC%20708cd2f9e0c64c6d9aac290edca04c74/Untitled%204.png)