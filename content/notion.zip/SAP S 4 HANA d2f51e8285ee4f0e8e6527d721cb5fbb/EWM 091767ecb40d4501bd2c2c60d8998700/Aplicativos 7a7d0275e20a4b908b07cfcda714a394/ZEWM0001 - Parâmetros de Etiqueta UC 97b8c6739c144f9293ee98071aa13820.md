# ZEWM0001 - Parâmetros de Etiqueta UC

Owner: Leonardo

Funcionalidades principais:

Cadastro de sigla de transportadora

Cadastro de cliente com etiqueta personalizada

![Untitled](ZEWM0001%20-%20Para%CC%82metros%20de%20Etiqueta%20UC%2097b8c6739c144f9293ee98071aa13820/Untitled.png)

![Untitled](ZEWM0001%20-%20Para%CC%82metros%20de%20Etiqueta%20UC%2097b8c6739c144f9293ee98071aa13820/Untitled%201.png)