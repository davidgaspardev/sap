# Base de Conhecimento

Owner: Leonardo

[Configurar Impressoras](Base%20de%20Conhecimento%20e32fcb45e11e4febb267a17c50e22c4a/Configurar%20Impressoras%20f0f343cfae0245c49c39e0541ef07424.md)

[Fazer requisições via Soap UI](Base%20de%20Conhecimento%20e32fcb45e11e4febb267a17c50e22c4a/Fazer%20requisic%CC%A7o%CC%83es%20via%20Soap%20UI%207ed41f1ecd6245bcb7d1c49a74b74d09.md)