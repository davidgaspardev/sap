# Configurar Impressoras

Owner: Leonardo

Para imprimir no SAP via Servidor de Impressão Windows com impressoras compartilhadas é necessário instalar no servidor windows o aplicativo SAPSprint.

SAPSprint é um programa de transferência para saída de impressão usando um sistema operacional Microsoft Windows

[https://help.sap.com/doc/saphelp_nw73ehp1/7.31.19/en-US/4e/658e17eb334dafe10000000a42189b/content.htm?no_cache=true](https://help.sap.com/doc/saphelp_nw73ehp1/7.31.19/en-US/4e/658e17eb334dafe10000000a42189b/content.htm?no_cache=true)

Apos instalado será necessário cadastrar as impressoras no SAP através da transação SPAD.

Cadastro de impressora - SPAD

![Untitled](Configurar%20Impressoras%20f0f343cfae0245c49c39e0541ef07424/Untitled.png)

![Untitled](Configurar%20Impressoras%20f0f343cfae0245c49c39e0541ef07424/Untitled%201.png)

![Untitled](Configurar%20Impressoras%20f0f343cfae0245c49c39e0541ef07424/Untitled%202.png)

![Untitled](Configurar%20Impressoras%20f0f343cfae0245c49c39e0541ef07424/Untitled%203.png)