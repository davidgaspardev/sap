# Fazer requisições via Soap UI

Owner: Leonardo

![Untitled](Fazer%20requisic%CC%A7o%CC%83es%20via%20Soap%20UI%207ed41f1ecd6245bcb7d1c49a74b74d09/Untitled.png)