# Aplicativos

Owner: Leonardo

ST22

Monitora execucao ABAP

![Untitled](Aplicativos%202a815ccc8a7f43969a3edd72cc9e1791/Untitled.png)

Debugar 

![Untitled](Aplicativos%202a815ccc8a7f43969a3edd72cc9e1791/Untitled%201.png)

SE38

![Untitled](Aplicativos%202a815ccc8a7f43969a3edd72cc9e1791/Untitled%202.png)

Encontrar nome do programa ABAPI

![Untitled](Aplicativos%202a815ccc8a7f43969a3edd72cc9e1791/Untitled%203.png)

![Untitled](Aplicativos%202a815ccc8a7f43969a3edd72cc9e1791/Untitled%204.png)

transacoes

![Untitled](Aplicativos%202a815ccc8a7f43969a3edd72cc9e1791/Untitled%205.png)

![Untitled](Aplicativos%202a815ccc8a7f43969a3edd72cc9e1791/Untitled%206.png)

![Untitled](Aplicativos%202a815ccc8a7f43969a3edd72cc9e1791/Untitled%207.png)

[Favoritos](Aplicativos%202a815ccc8a7f43969a3edd72cc9e1791/Favoritos%20c7fd1552789943a3b7109ed44e540b40.md)

Numero de Serie

/ois2

Config de perfil

![Untitled](Aplicativos%202a815ccc8a7f43969a3edd72cc9e1791/Untitled%208.png)

Exibir codigo da transacao no menu - exibir nomes tecnicos

![Untitled](Aplicativos%202a815ccc8a7f43969a3edd72cc9e1791/Untitled%209.png)

![Untitled](Aplicativos%202a815ccc8a7f43969a3edd72cc9e1791/Untitled%2010.png)