# Como encontrar código ABAP de Smartforms

Owner: Leonardo

![Untitled](Como%20encontrar%20co%CC%81digo%20ABAP%20de%20Smartforms%2031f5ed04a867435ea445b41958f8b32f/Untitled.png)

![Untitled](Como%20encontrar%20co%CC%81digo%20ABAP%20de%20Smartforms%2031f5ed04a867435ea445b41958f8b32f/Untitled%201.png)

![Untitled](Como%20encontrar%20co%CC%81digo%20ABAP%20de%20Smartforms%2031f5ed04a867435ea445b41958f8b32f/Untitled%202.png)

Abrir a função encontrada no editor ABAP SE37

![Untitled](Como%20encontrar%20co%CC%81digo%20ABAP%20de%20Smartforms%2031f5ed04a867435ea445b41958f8b32f/Untitled%203.png)

Clicar no nome e pressionar Control + F para abrir a caixa de pesquisa

![Untitled](Como%20encontrar%20co%CC%81digo%20ABAP%20de%20Smartforms%2031f5ed04a867435ea445b41958f8b32f/Untitled%204.png)

Informar o texto a ser pesquisado

![Untitled](Como%20encontrar%20co%CC%81digo%20ABAP%20de%20Smartforms%2031f5ed04a867435ea445b41958f8b32f/Untitled%205.png)

Clicar duas vezes no código

![Untitled](Como%20encontrar%20co%CC%81digo%20ABAP%20de%20Smartforms%2031f5ed04a867435ea445b41958f8b32f/Untitled%206.png)

Codigo exibido

![Untitled](Como%20encontrar%20co%CC%81digo%20ABAP%20de%20Smartforms%2031f5ed04a867435ea445b41958f8b32f/Untitled%207.png)