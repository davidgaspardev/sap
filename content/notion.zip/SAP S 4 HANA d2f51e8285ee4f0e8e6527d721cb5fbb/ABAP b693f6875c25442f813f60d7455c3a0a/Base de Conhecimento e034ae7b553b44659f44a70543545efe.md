# Base de Conhecimento

Owner: Leonardo

[Como encontrar código ABAP de Smartforms](Base%20de%20Conhecimento%20e034ae7b553b44659f44a70543545efe/Como%20encontrar%20co%CC%81digo%20ABAP%20de%20Smartforms%2031f5ed04a867435ea445b41958f8b32f.md)