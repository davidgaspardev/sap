# SAP S/4 HANA

Ofereça aos seus colegas um espaço para aprender sobre a sua equipe e no que vocês estão trabalhando. Use os botões + na sua barra lateral esquerda para adicionar mais página, como documentos de processos ou um roadmap de projetos.

<aside>
👋 Bem-vindo à equipe! Nossa missão é…

Dúvidas? Saiba onde nos encontrar:

- Canal no Slack:
- E-mail:
- Administrador da equipe:
</aside>

## Módulos

---

[ABAP](SAP%20S%204%20HANA%20d2f51e8285ee4f0e8e6527d721cb5fbb/ABAP%20b693f6875c25442f813f60d7455c3a0a.md)

[Basis](SAP%20S%204%20HANA%20d2f51e8285ee4f0e8e6527d721cb5fbb/Basis%20356fa14682b946c88626ab2fd154d7b9.md)

[EWM](SAP%20S%204%20HANA%20d2f51e8285ee4f0e8e6527d721cb5fbb/EWM%20091767ecb40d4501bd2c2c60d8998700.md)

[MM](SAP%20S%204%20HANA%20d2f51e8285ee4f0e8e6527d721cb5fbb/MM%20d4e2e0962c71410bb290d3c4f8ea8862.md)

[TM](SAP%20S%204%20HANA%20d2f51e8285ee4f0e8e6527d721cb5fbb/TM%20e8e31dea2e7f415bb8976ad56af0819c.md)

[SD](SAP%20S%204%20HANA%20d2f51e8285ee4f0e8e6527d721cb5fbb/SD%2046338ba21ac14683a1a42c13c653f767.md)

[QM](SAP%20S%204%20HANA%20d2f51e8285ee4f0e8e6527d721cb5fbb/QM%2063ca63de201d4d1abf2abe40dcb760be.md)

[PP](SAP%20S%204%20HANA%20d2f51e8285ee4f0e8e6527d721cb5fbb/PP%20274ac8df9c4c4b979e329007d19beb4f.md)

[Geral](SAP%20S%204%20HANA%20d2f51e8285ee4f0e8e6527d721cb5fbb/Geral%201d0a4048dbdf4b2d808311e4a4b8a7f9.md)